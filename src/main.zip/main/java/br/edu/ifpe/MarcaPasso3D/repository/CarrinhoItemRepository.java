package br.edu.ifpe.MarcaPasso3D.repository;

import br.edu.ifpe.MarcaPasso3D.model.CarrinhoItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarrinhoItemRepository extends JpaRepository<CarrinhoItem, Long> {
}