package br.edu.ifpe.MarcaPasso3D.repository;

import br.edu.ifpe.MarcaPasso3D.model.Carrinho;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CarrinhoRepository extends JpaRepository<Carrinho, Long> {
    Optional<Carrinho> findByIdUsuario(Long idUsuario);
} 